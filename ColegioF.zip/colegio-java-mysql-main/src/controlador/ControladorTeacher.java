/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;
import java.util.LinkedList;
import modelo.BaseDatos;
import modelo.Teacher;
/**
 *
 * @author usuario
 */
public class ControladorTeacher {
     public boolean insertTeacher(Teacher objs) {
        boolean T=false;
        String sql="insert into students(name1S,name2S,surname1S,surname2S,mobileS,adressS,stratumS,institutionalEmailS,custodianMobile1,custodianMobile2,userS,passwordS,idCitiesfk,idGenderfk) values('"+objs.getName1T()+"','"+objs.getName2T()+"','"+objs.getSuname1T()+"','"+objs.getSuname2T()+"','"+objs.getMobileT()+"','"+objs.getAddressT()+"','"+objs.getStratumT()+"','"+objs.getInstitutionalEmailT()+"','"+objs.getBusinessPositionT()+"','"+objs.getWorkDay()+"','"+objs.getUserT()+"','"+objs.getPasswordT()+"','"+objs.getIdCityfk()+"','"+objs.getIdGenderfk()+"');";
        BaseDatos objbd=new BaseDatos();
        T=objbd.ejecutarSQL(sql);
        return T;              
    }
}
